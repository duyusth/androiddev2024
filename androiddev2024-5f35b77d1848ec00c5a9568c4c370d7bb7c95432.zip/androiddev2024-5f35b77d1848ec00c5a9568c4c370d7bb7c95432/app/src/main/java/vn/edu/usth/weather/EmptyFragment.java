package vn.edu.usth.weather;

import androidx.fragment.app.Fragment;

public class EmptyFragment extends Fragment {
}
