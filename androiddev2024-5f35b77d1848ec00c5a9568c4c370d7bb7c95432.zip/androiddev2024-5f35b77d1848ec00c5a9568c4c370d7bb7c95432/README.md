USTH ICT 2024 Android Application Development
=====================================================

Students are expected to:

* Fork this repository to your github account
* Update student name and ID to this README file
* Push your commits regularly, with proper commit messages

Student Info
=======================

* Name: Truong Quang Nam
* ID: BA12-134

* Group ID: *Your Group ID here*
* Project Name: *Your Project Name here*
